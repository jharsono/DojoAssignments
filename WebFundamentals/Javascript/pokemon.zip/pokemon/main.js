  $(document).ready(function(){
    alert('it works');
    for(var i = 1; i <= 151; i++) {
      $("body").append("<img src='http://pokeapi.co/media/img/"+i+".png'>")
    };

});
